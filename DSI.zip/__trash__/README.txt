Este directorio es un staging temporal para eliminaciones confirmadas por el usuario.
Archivos movidos aquí serán removidos definitivamente al finalizar la sesión de limpieza.